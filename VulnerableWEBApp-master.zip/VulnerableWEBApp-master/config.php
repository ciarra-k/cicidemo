<?php
//Connection to database
 
 $db = mysqli_connect("127.0.0.1","test","test","project")
 or die('Error connecting to MySQL server.');
?>
